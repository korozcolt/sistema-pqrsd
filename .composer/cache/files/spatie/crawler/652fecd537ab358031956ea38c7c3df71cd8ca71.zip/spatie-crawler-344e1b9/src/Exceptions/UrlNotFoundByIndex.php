<?php

namespace Spatie\Crawler\Exceptions;

use RuntimeException;

class UrlNotFoundByIndex extends RuntimeException {}
