<?php

namespace Opcodes\LogViewer\Exceptions;

use Exception;

class CannotOpenFileException extends Exception {}
