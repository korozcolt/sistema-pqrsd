<?php

namespace Opcodes\LogViewer\Exceptions;

use Exception;

class InvalidChunkSizeException extends Exception {}
