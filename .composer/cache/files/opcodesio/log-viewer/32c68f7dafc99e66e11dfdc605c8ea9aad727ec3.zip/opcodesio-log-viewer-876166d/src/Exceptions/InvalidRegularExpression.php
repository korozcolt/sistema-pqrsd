<?php

namespace Opcodes\LogViewer\Exceptions;

use Exception;

class InvalidRegularExpression extends Exception {}
