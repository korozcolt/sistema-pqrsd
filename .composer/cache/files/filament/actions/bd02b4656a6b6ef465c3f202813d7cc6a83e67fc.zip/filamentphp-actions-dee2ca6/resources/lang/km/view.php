<?php

return [

    'single' => [

        'label' => 'មើល',

        'modal' => [

            'heading' => 'មើល :label',

            'actions' => [

                'close' => [
                    'label' => 'បិទ',
                ],

            ],

        ],

    ],

];
