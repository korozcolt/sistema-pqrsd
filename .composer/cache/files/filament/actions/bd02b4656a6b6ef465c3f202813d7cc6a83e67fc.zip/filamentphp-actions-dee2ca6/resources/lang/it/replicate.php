<?php

return [

    'single' => [

        'label' => 'Duplica',

        'modal' => [

            'heading' => 'Duplica :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplica',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Duplicato',
            ],

        ],

    ],

];
