<?php

return [

    'single' => [

        'label' => 'Associar',

        'modal' => [

            'heading' => 'Associar :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registre',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associar',
                ],

                'associate_another' => [
                    'label' => 'Associar i associar un altre',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Associat',
            ],

        ],

    ],

];
