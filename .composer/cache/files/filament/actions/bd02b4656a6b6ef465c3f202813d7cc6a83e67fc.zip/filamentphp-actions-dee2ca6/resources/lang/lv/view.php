<?php

return [

    'single' => [

        'label' => 'Skatīt',

        'modal' => [

            'heading' => 'Skatīt :label',

            'actions' => [

                'close' => [
                    'label' => 'Aizvērt',
                ],

            ],

        ],

    ],

];
