<?php

return [

    'single' => [

        'label' => 'Odpojit',

        'modal' => [

            'heading' => 'Odpojit :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Odpojit',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Odpojeno',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Odpojit zvolené',

        'modal' => [

            'heading' => 'Odpojit zvolené :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Odpojit zvolené',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Odpojeno',
            ],

        ],

    ],

];
