<?php

return [

    'single' => [

        'label' => 'Դիտել',

        'modal' => [

            'heading' => 'Դիտել :labelը',

            'actions' => [

                'close' => [
                    'label' => 'Փակել',
                ],

            ],

        ],

    ],

];
