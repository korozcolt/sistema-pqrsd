<?php

return [

    'single' => [

        'label' => 'Povežite',

        'modal' => [

            'heading' => 'Povežite :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Zapis',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Povežite',
                ],

                'associate_another' => [
                    'label' => 'Povežite i povežite još jedan',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Povezano',
            ],

        ],

    ],

];
