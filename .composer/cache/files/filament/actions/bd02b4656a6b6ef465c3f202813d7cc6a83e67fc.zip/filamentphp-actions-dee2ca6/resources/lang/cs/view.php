<?php

return [

    'single' => [

        'label' => 'Zobrazit',

        'modal' => [

            'heading' => 'Zobrazit :label',

            'actions' => [

                'close' => [
                    'label' => 'Zavřít',
                ],

            ],

        ],

    ],

];
