<?php

return [

    'single' => [

        'label' => 'Həmişəlik sil',

        'modal' => [

            'heading' => ':label həmişəlik sil',

            'actions' => [

                'delete' => [
                    'label' => 'Həmişəlik sil',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Məlumat həmişəlik silindi',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Seçilənləri həmişəlik sil',

        'modal' => [

            'heading' => ':label seçilənləri həmişəlik sil',

            'actions' => [

                'delete' => [
                    'label' => 'Həmişəlik sil',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Məlumat həmişəlik silindi',
            ],

        ],

    ],

];
