<?php

return [

    'single' => [

        'label' => 'Կցել',

        'modal' => [

            'heading' => 'Կցել :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Գրառումներ',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Կցել',
                ],

                'attach_another' => [
                    'label' => 'Կցել և կցել մեկ այլ',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Կցվել է',
            ],

        ],

    ],

];
