<?php

return [

    'single' => [

        'label' => 'Засах',

        'modal' => [

            'heading' => 'Засах :label',

            'actions' => [

                'save' => [
                    'label' => 'Хадгалах',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Хадгалсан',
            ],

        ],

    ],

];
