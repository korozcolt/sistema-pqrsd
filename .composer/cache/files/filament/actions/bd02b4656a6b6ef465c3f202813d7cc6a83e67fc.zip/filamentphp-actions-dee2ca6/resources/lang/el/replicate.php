<?php

return [

    'single' => [

        'label' => 'Αντιγραφή',

        'modal' => [

            'heading' => 'Αντιγραφή :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Αντιγραφή',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Αντιγράφηκε επιτυχώς',
            ],

        ],

    ],

];
