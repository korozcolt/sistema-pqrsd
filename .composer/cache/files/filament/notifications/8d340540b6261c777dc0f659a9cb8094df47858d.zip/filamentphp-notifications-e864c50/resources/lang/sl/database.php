<?php

return [

    'modal' => [

        'heading' => 'Obvestila',

        'actions' => [

            'clear' => [
                'label' => 'Počisti',
            ],

            'mark_all_as_read' => [
                'label' => 'Označi vse kot prebrano',
            ],

        ],

        'empty' => [
            'heading' => 'Ni obvestil',
            'description' => 'Prosimo, preverite ponovno kasneje.',
        ],

    ],

];
