<?php

return [

    'distinct' => [
        'must_be_selected' => 'Musí být vybráno alespoň jedno pole :attribute.',
        'only_one_must_be_selected' => 'Musí být vybráno pouze jedno pole :attribute.',
    ],

];
