<div
    {{ $attributes->class(['fi-fo-field-wrp-helper-text break-words text-sm text-gray-500']) }}
>
    {{ $slot }}
</div>
