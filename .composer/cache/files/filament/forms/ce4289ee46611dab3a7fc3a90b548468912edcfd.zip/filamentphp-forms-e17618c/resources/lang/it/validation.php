<?php

return [

    'distinct' => [
        'must_be_selected' => 'È necessario selezionare almeno un campo :attribute.',
        'only_one_must_be_selected' => 'È necessario selezionare un solo campo :attribute.',
    ],

];
