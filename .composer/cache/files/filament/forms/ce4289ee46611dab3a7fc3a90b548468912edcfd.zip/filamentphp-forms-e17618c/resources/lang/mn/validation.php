<?php

return [

    'distinct' => [
        'must_be_selected' => ':attribute багадаа нэгийг сонгосон байх ёстой.',
        'only_one_must_be_selected' => ':attribute зөвхөн нэгийг сонгосон байх ёстой.',
    ],

];
