<?php

return [

    'distinct' => [
        'must_be_selected' => 'Minst én :attribute felt må være valgt.',
        'only_one_must_be_selected' => 'Bare én :attribute felt må være valgt.',
    ],

];
