<?php

return [

    'title' => 'Pregled :label',

    'breadcrumb' => 'Pregledaj',

    'content' => [

        'tab' => [
            'label' => 'Pregled',
        ],

    ],

];
