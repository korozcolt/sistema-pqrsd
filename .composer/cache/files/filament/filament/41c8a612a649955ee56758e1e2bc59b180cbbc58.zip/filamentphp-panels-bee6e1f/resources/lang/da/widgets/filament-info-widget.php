<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentation',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
