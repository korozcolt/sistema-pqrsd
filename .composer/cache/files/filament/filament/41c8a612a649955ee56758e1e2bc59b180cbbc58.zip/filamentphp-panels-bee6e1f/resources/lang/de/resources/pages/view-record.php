<?php

return [

    'title' => ':label ansehen',

    'breadcrumb' => 'Ansehen',

    'content' => [

        'tab' => [
            'label' => 'Ansehen',
        ],

    ],

];
