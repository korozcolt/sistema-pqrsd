<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Dəyişiklikləri Yadda Saxla',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Yadda Saxlanıldı',
        ],

    ],

];
