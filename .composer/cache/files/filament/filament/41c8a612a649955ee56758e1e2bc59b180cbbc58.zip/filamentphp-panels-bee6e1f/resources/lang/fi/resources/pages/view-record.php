<?php

return [

    'title' => 'Näytä :label',

    'breadcrumb' => 'Näytä',

    'content' => [

        'tab' => [
            'label' => 'Näytä',
        ],

    ],

];
