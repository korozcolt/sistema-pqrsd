<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'خروج',
        ],

    ],

    'welcome' => 'خوش آمدید',

];
