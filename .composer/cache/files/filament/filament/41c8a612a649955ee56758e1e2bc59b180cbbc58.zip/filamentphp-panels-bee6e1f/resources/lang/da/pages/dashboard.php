<?php

return [

    'title' => 'Dashboard',

    'actions' => [

        'filter' => [

            'label' => 'Filtrer',

            'modal' => [

                'heading' => 'Filter',

                'actions' => [

                    'apply' => [

                        'label' => 'Anvend',

                    ],

                ],

            ],

        ],

    ],

];
