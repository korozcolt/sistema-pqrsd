<?php

return [

    'title' => 'Redaguoti :label',

    'breadcrumb' => 'Redaguoti',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Atšaukti',
            ],

            'save' => [
                'label' => 'Išsaugoti pakeitimus',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Redaguoti',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Išsaugota',
        ],

    ],

];
