<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Документация',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
