<?php

return [

    'title' => 'Табло',

    'actions' => [

        'filter' => [

            'label' => 'Филтър',

            'modal' => [

                'heading' => 'Филтриране',

                'actions' => [

                    'apply' => [

                        'label' => 'Приложи',

                    ],

                ],

            ],

        ],

    ],

];
