<?php

return [

    'title' => 'Dasbor',

    'actions' => [

        'filter' => [

            'label' => 'Filter',

            'modal' => [

                'heading' => 'Filter',

                'actions' => [

                    'apply' => [

                        'label' => 'Terapkan',

                    ],

                ],

            ],

        ],

    ],

];
