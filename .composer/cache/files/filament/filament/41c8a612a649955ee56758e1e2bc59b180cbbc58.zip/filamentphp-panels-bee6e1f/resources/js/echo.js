import Echo from 'laravel-echo'
import Pusher from 'pusher-js/dist/web/pusher'

window.EchoFactory = Echo
window.Pusher = Pusher
