<?php

return [

    'field' => [
        'label' => 'Globali paieška',
        'placeholder' => 'Paieška',
    ],

    'no_results_message' => 'Paieškos rezultatų nėra.',

];
