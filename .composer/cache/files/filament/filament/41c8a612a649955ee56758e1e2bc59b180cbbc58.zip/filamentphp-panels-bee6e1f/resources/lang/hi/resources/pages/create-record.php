<?php

return [

    'title' => ':label बनाएँ',

    'breadcrumb' => 'बनाएँ',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'रद्द करें',
            ],

            'create' => [
                'label' => 'बनाएँ',
            ],

            'create_another' => [
                'label' => 'बनाएँ और एक और बनाएँ',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'बन गया',
        ],

    ],

];
