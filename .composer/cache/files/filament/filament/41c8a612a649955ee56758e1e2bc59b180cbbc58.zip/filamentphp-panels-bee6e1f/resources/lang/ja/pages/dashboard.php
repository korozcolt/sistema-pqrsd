<?php

return [

    'title' => 'ダッシュボード',

    'actions' => [

        'filter' => [

            'label' => 'フィルタ',

            'modal' => [

                'heading' => 'フィルタ',

                'actions' => [

                    'apply' => [

                        'label' => '適用',

                    ],

                ],

            ],

        ],

    ],

];
