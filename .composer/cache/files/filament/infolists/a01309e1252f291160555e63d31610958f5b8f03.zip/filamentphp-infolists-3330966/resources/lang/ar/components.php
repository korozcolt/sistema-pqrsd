<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'عرض :count أقل',
                'expand_list' => 'عرض :count أكثر',
            ],

            'more_list_items' => 'و :count إضافية',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'المفتاح',
                ],

                'value' => [
                    'label' => 'القيمة',
                ],

            ],

            'placeholder' => 'لا توجد مدخلات',

        ],

    ],

];
