<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Prikaži :count manje',
                'expand_list' => 'Prikaži :count više',
            ],

            'more_list_items' => 'and :count more',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Ključ',
                ],

                'value' => [
                    'label' => 'Vrijednost',
                ],

            ],

            'placeholder' => 'Nema unosa',

        ],

    ],

];
