<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Сховати :count',
                'expand_list' => 'Показати ще :count',
            ],

            'more_list_items' => 'ще :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Ключ',
                ],

                'value' => [
                    'label' => 'Значення',
                ],

            ],

            'placeholder' => 'Немає записів',

        ],

    ],

];
