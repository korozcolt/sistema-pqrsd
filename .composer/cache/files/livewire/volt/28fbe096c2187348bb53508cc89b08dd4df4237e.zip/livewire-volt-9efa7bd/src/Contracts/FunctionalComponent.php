<?php

namespace Livewire\Volt\Contracts;

interface FunctionalComponent
{
    //
}
